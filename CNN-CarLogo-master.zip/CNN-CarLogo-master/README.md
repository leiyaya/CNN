# CNN-CarLogo
🤖CNN卷积神经网络 实现汽车🚘logo图像识别

# 项目效果
## 用下面6张汽车logo对神经网络进行训练

![logos.png](http://upload-images.jianshu.io/upload_images/5716959-022394d424b89688.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

 
 ## 对页面上的logo进行识别
可以发现多次训练之后，结果趋向稳定，一直都是正确的 奥迪

![result.png](http://upload-images.jianshu.io/upload_images/5716959-02e475658b9a96cc.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


GitHub: [GitHub链接](https://github.com/yllg/CNN-CarLogo)
</br>
欢迎小伙伴们star~~~
